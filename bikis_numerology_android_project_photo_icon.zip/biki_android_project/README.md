# Biki's Numerology Android app

This Android wrapper loads the supplied website from the app's bundled assets, so the calculator UI and its local assets do not need an internet connection. The app may attempt to load Google Fonts from the internet; it falls back to local system fonts when offline.

## Build an installable APK using GitHub Actions
1. Upload the contents of this project to the root of your GitHub repository, preserving folders including `.github/workflows`.
2. Open the repository's **Actions** tab.
3. Select **Build Android APK** and tap **Run workflow** (or let it run after pushing to `main`).
4. When the run completes successfully, open the run and download the `bikis-numerology-apk` artifact.
5. Extract the downloaded artifact ZIP and install `app-debug.apk` on your Android phone. Android may ask you to allow installation from that source.

This is a debug APK suitable for personal installation, not a Play Store release. The bundled website is loaded locally. Any external fonts are optional and may not appear offline.
